module.exports = {
  stories: ["../src/**/*.stories.mdx"],
  addons: [
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "@storybook/preset-scss",

    {
      name: "@storybook/addon-docs",
      options: {
        configureJSX: true,
        babelOptions: {},
        sourceLoaderOptions: null
      }
    },
    {
      transform: {
        "^.+\\.[tj]sx?$": "babel-jest",
        "^.+\\.mdx$": "@storybook/addon-docs/jest-transform-mdx"
      }
    }
  ],
  webpackFinal: async defaultConf => {
    const rules = defaultConf.module.rules;
    const tsLoaderRule = rules.find(rule => rule.test.test(".tsx"));
    tsLoaderRule.use[0].options.plugins.push([
      "babel-plugin-named-asset-import",
      {
        loaderMap: {
          svg: {
            ReactComponent: "@svgr/webpack?-svgo,+titleProp,+ref![path]"
          }
        }
      }
    ]);

    return defaultConf;
  }
};

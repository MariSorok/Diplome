import React, { useMemo } from "react";
import { hot } from "react-hot-loader";
import BaseLayout from "../layouts/main";
import Header from "../components/header";
import styles from "./styles.module.scss";
import { ReactComponent as Balance } from "./images/balance.svg";
import { ReactComponent as Account } from "./images/account.svg";
import { ReactComponent as Orders } from "./images/orders.svg";
import { Switch, Route } from "react-router-dom";
import Footer from "../components/footer";

const App = () => {
  const unauthorizedHeaderContent = useMemo(
    () => ({
      sectionMenu: [
        { link: "/", title: "Каталог заявок" },
        { link: "/", title: "Каталог бригад" },
        { link: "/", title: "Блог" },
      ],
    }),
    []
  );

  const authorizedContractorHeaderContent = useMemo(
    () => ({
      sectionMenu: [
        { link: "/", title: "Каталог заявок" },
        { link: "/", title: "Каталог бригад" },
        { link: "/", title: "Блог" },
      ],
      dropdownMenu: [
        { link: "/", title: "Мои заявки", icon: <Orders /> },
        { link: "/", title: "Профиль", icon: <Account /> },
      ],
    }),
    []
  );

  const authorizedClientHeaderContent = useMemo(
    () => ({
      sectionMenu: [
        { link: "/", title: "Каталог заявок" },
        { link: "/", title: "Каталог бригад" },
        { link: "/", title: "Блог" },
      ],
      dropdownMenu: [
        { link: "/", title: "Мои заявки", icon: <Orders /> },
        { link: "/", title: "Управление личным кабинетом", icon: <Account /> },
      ],
    }),
    []
  );
  return (
    <div className={styles.root}>
      <div className={styles.headerWrapper}>
        <Header menu={authorizedContractorHeaderContent} user='contractor' />
      </div>
      <BaseLayout>
        <Switch>
          <Route exact path='/' component={"Home"} />
        </Switch>
      </BaseLayout>
      <Footer />
    </div>
  );
};

declare let module: Record<string, unknown>;

export default hot(module)(App);

import React from "react";
import styles from "./styles.module.scss";
import cx from "clsx";
import { Container, Row, Col } from "react-grid-system";
import { ReactComponent as Logo } from "../header/images/usta.ru.svg";
import Text from "../../components/ui-kit/text";
import Link from "../../components/ui-kit/link";
import useDevice, { Device } from "../../tools/media";

type FooterProps = {
  className?: string;
};

const MENU = [
  { href: "#", label: "Каталог заявок" },
  { href: "#", label: "Каталог бригад" },
  { href: "#", label: "Блог" },
  { href: "#", label: "Пользовательское соглашение" },
];

const otherProps = {
  __self: typeof globalThis,
};

export default function Footer({ className }: FooterProps) {
  const device = useDevice();
  return (
    <div className={cx(styles.root, className)}>
      <Container className={styles.upperFooter} {...otherProps}>
        <Row {...otherProps}>
          <Col md={device === Device.Mobile ? 12 : undefined} {...otherProps}>
            <Logo className={styles.logo} />
            <Text level='4' className={styles.text}>
              2021 © Все права защишены
            </Text>
          </Col>
          <Col
            className={styles.menu}
            md={device === Device.Mobile ? 12 : undefined}
          >
            {MENU.map((menuItem) => (
              <Link
                href={menuItem.href}
                type='secondary'
                className={styles.menuItem}
              >
                <Text level='3'>{menuItem.label}</Text>
              </Link>
            ))}
          </Col>
          <Col
            className={styles.contactWrapper}
            offset={{ md: device === Device.Desktop ? 1 : undefined }}
          >
            <div>
              <Text level='6' className={styles.text}>
                Задать вопрос
              </Text>
              <Text level='2' className={styles.contact}>
                8 495 777-77-77
              </Text>
            </div>
            <div className={styles.contactItem}>
              <Text level='6' className={styles.text}>
                Написать нам
              </Text>
              <Text level='2' className={styles.contact}>
                info@usta.ru
              </Text>
            </div>
          </Col>
        </Row>
      </Container>
      <Container className={styles.footer} {...otherProps}>
        <Text level='4' className={styles.text}>
          Разработка дизайна сайта — WebVibe
        </Text>
      </Container>
    </div>
  );
}

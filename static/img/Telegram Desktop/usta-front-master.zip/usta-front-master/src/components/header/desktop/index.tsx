import React, { useState, ReactElement } from "react";
import cx from "clsx";
import styles from "./styles.module.scss";
import { ReactComponent as Logo } from "../images/usta.ru.svg";
import Link from "../../ui-kit/link";
import Text from "../../ui-kit/text";
import Button from "../../ui-kit/button";
import { ReactComponent as Dropdown } from "../images/dropdown.svg";
import { ReactComponent as Dropup } from "../images/dropup.svg";
import { Container } from "react-grid-system";

import Box from "../../ui-kit/box";

type Menu = {
  link: string;
  title: string;
  icon?: ReactElement;
};

type HeaderProps = {
  className?: string;
  menu: {
    sectionMenu: Menu[];
    dropdownMenu?: Menu[];
  };
  user?: "contractor" | "client" | "unauthorizedUser";
};

const otherProps = {
  __self: typeof globalThis,
};

export default function DesktopHeader({ menu, className, user }: HeaderProps) {
  const [dropdownMenu, setDropdownMenu] = useState<boolean>(false);
  return (
    <Container className={cx(className, styles.root)} {...otherProps}>
      <div className={styles.navWrapper}>
        <Logo />
        <div className={styles.sections}>
          {menu.sectionMenu.map((section) => {
            return (
              <Link
                href={section.link}
                className={styles.section}
                key={section.title}
              >
                <Text level='3'>{section.title}</Text>
              </Link>
            );
          })}
        </div>
        <div className={styles.buttonWrapper}>
          {user === "unauthorizedUser" ? (
            <>
              <Link href='/'>
                <Button color='default' className={styles.button}>
                  <Text level='3'>Войти</Text>
                </Button>
              </Link>
              <Link href='/'>
                <Button color='primary'>
                  <Text level='3'>Разместить задание</Text>
                </Button>
              </Link>
            </>
          ) : user === "contractor" ? (
            <div className={styles.buttonWrapper}>
              <>
                <Link href='/'>
                  <Button color='primary'>
                    <Text level='3'>Найти работу</Text>
                  </Button>
                </Link>
              </>
            </div>
          ) : (
            <>
              <Link href='/'>
                <Button color='primary'>
                  <Text level='3'>Создать заявку</Text>
                </Button>
              </Link>
            </>
          )}
        </div>
        {menu.dropdownMenu && (
          <Dropup
            onClick={() => setDropdownMenu(!dropdownMenu)}
            className={cx(styles.dropdownIcon, {
              [styles._rotated]: dropdownMenu,
            })}
          />
        )}
        <Box
          className={cx(styles.dropdownMenu, {
            [styles.dropdownMenu_opened]: dropdownMenu === true,
          })}
        >
          {menu.dropdownMenu?.map((section) => {
            return (
              <Link
                href={section.link}
                key={section.title}
                className={styles.dropdownMenuItem}
              >
                <div className={styles.dropdownMenuIcon}>{section.icon}</div>
                <Text level='3'>{section.title}</Text>
              </Link>
            );
          })}
        </Box>
      </div>
    </Container>
  );
}

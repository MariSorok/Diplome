import React, { ReactElement } from "react";
import useDevice, { Device } from "../../tools/media";
import DesktopHeader from "./desktop";
import MobileHeader from "./mobile";

type Menu = {
  link: string;
  title: string;
  icon?: ReactElement;
};

type HeaderProps = {
  className?: string;
  menu: {
    sectionMenu: Menu[];
    dropdownMenu?: Menu[];
  };
  user?: "contractor" | "client" | "unauthorizedUser";
};

export default function Header({ menu, className, user }: HeaderProps) {
  const device = useDevice();
  return (
    <>
      {device === Device.Mobile ? (
        <MobileHeader menu={menu} className={className} user={user} />
      ) : (
        <DesktopHeader menu={menu} className={className} user={user} />
      )}
    </>
  );
}

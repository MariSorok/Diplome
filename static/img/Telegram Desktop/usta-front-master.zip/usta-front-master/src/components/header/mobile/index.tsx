import React, { useState, ReactElement } from "react";
import cx from "clsx";
import styles from "./styles.module.scss";
import { ReactComponent as Logo } from "../images/usta.ru.svg";
import Link from "../../ui-kit/link";
import Text from "../../ui-kit/text";
import { ReactComponent as Burger } from "../images/burger.svg";
import { ReactComponent as Cancel } from "../images/cancel.svg";
import { Container } from "react-grid-system";
import Button from "../../ui-kit/button";

type Menu = {
  link: string;
  title: string;
  icon?: ReactElement;
};

type HeaderProps = {
  className?: string;
  menu: {
    sectionMenu: Menu[];
    dropdownMenu?: Menu[];
  };
  user?: "contractor" | "client" | "unauthorizedUser";
};

const otherProps = {
  __self: typeof globalThis,
};

export default function MobileHeader({ menu, className, user }: HeaderProps) {
  const [isMenuOpened, setIsMenuOpened] = useState<boolean>(false);
  return (
    <Container className={cx(className, styles.root)} {...otherProps}>
      <div className={styles.navWrapper}>
        <Logo />
        <div className={styles.navIcon}>
          {isMenuOpened ? (
            <Cancel
              className={styles.menuIcon}
              onClick={() => setIsMenuOpened(false)}
            />
          ) : (
            <Burger
              className={styles.menuIcon}
              onClick={() => setIsMenuOpened(true)}
            />
          )}
        </div>
      </div>
      <div
        className={cx(styles.menu, {
          [styles.menu_opened]: isMenuOpened,
        })}
      >
        <div className={styles.menuItems}>
          <div className={styles.sections}>
            {menu.sectionMenu.map((section) => {
              return (
                <Link
                  href={section.link}
                  className={styles.section}
                  key={section.link}
                >
                  <Text level='1'>{section.title}</Text>
                </Link>
              );
            })}
          </div>
          <div className={styles.dropdownMenu}>
            {menu.dropdownMenu?.map((section) => {
              return (
                <Link
                  href={section.link}
                  key={section.link}
                  className={styles.dropdownMenuItem}
                >
                  <Text level='1'>{section.title}</Text>
                </Link>
              );
            })}
          </div>
          <div className={styles.buttonWrapper}>
            {user === "unauthorizedUser" ? (
              <>
                <Link href='/' className={styles.section}>
                  <Button color='default' className={styles.button}>
                    <Text level='3'>Войти</Text>
                  </Button>
                </Link>
                <Link href='/' className={styles.section}>
                  <Button color='primary' className={styles.button}>
                    <Text level='3'>Разместить задание</Text>
                  </Button>
                </Link>
              </>
            ) : user === "contractor" ? (
              <div className={styles.buttonWrapper}>
                <>
                  <Link href='/' className={styles.section}>
                    <Button color='primary' className={styles.button}>
                      <Text level='3'>Найти работу</Text>
                    </Button>
                  </Link>
                </>
              </div>
            ) : (
              <>
                <Link href='/' className={styles.section}>
                  <Button color='primary' className={styles.button}>
                    <Text level='3'>Создать заявку</Text>
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </Container>
  );
}

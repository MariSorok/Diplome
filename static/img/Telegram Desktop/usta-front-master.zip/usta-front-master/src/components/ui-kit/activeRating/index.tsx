import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Rating from "@material-ui/lab/Rating";
import { ReactComponent as Star } from "./images/star.svg";
import styles from "./styles.module.scss";
import cx from "clsx";
import useDevice, { Device } from "../../../tools/media";

const StyledRating = withStyles({
  label: {
    paddingRight: "12px"
  },
  iconFilled: {
    color: "#FFCC00",
    transition: "0.3s ease"
  },
  iconHover: {
    color: "#FFCC00"
  }
})(Rating);

type ActiveRatingProps = {
  value?: number;
  className?: string;
  defaultValue?: number;
  onChange?: (event: object, value: number) => void;
  name?: string;
};
export default function ActiveRating({
  value,
  className,
  defaultValue = 0,
  onChange,
  name
}: ActiveRatingProps) {
  const device = useDevice();
  return (
    <div className={cx(styles.root, className)}>
      <StyledRating
        name={name}
        value={value}
        defaultValue={defaultValue}
        icon={<Star />}
        onChange={onChange}
      />
      {device !== Device.Mobile && (
        <div className={styles.value}>{value}.0</div>
      )}
    </div>
  );
}

import React, { ReactNode } from "react";
import cx from "clsx";
import styles from "./styles.module.scss";

type BoxProps = {
  hover?: boolean;
  className?: string;
  color?: "grey" | "white";
  children?: ReactNode;
};
export default function Box({
  className,
  color = "white",
  children,
  hover = false
}: BoxProps) {
  return (
    <div
      className={cx(styles.root, className, styles[`_color_${color}`], {
        [styles["_hover"]]: hover
      })}
    >
      {children}
    </div>
  );
}

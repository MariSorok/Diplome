import React, { ReactNode } from "react";
import { Button as MUIButton } from "@material-ui/core";
import cx from "clsx";
import styles from "./styles.module.scss";
import { ReactComponent as Delete } from "./images/delete.svg";
import { ReactComponent as Edit } from "./images/edit.svg";
import { createStyles, makeStyles } from "@material-ui/core/styles";

type ButtonProps = {
  variant?: "text" | "outlined" | "contained";
  color?: "inherit" | "primary" | "secondary" | "default";
  href?: string;
  disabled?: boolean;
  size?: "small" | "medium" | "large";
  className?: string;
  children?: ReactNode;
  onClick?: () => void;
  isRound?: boolean;
  type?: "edit" | "delete";
};

const otherProps = {
  __self: typeof globalThis,
};

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      "& .MuiButton-root": {
        fontSize: "0",
        letterSpacing: "0",
        textTransform: "none",
      },
    },
  })
);

export default function Button({
  variant,
  color = "default",
  href,
  disabled,
  size = "medium",
  className,
  children,
  onClick,
  isRound,
  type,
}: ButtonProps) {
  const classes = useStyles();

  return (
    <div
      className={cx(styles.root, classes.root, className, {
        [styles["_disabled"]]: disabled,
      })}
    >
      <MUIButton
        {...otherProps}
        className={cx(
          styles.muiButton,
          styles[`_color_${color}`],
          styles[`_size_${size}`],
          styles[`_type_${type}`],
          {
            [styles["_isRound"]]: isRound,
          }
        )}
        variant={variant}
        size={size}
        href={href}
        disabled={disabled}
        color={color}
        onClick={onClick}
      >
        {type === "delete" ? <Delete /> : type === "edit" ? <Edit /> : children}
      </MUIButton>
    </div>
  );
}

import React, { ReactElement } from "react";
import Fab from "@material-ui/core/Fab";
import cx from "clsx";
import styles from "./styles.module.scss";

type FloatingActionButtonProps = {
  size?: "small" | "medium" | "large";
  color?: "default" | "inherit" | "primary" | "secondary";
  disabled?: boolean;
  children: string | number | ReactElement;
  className?: string;
  href?: string;
  variant?: "extended" | "round";
};
export default function FloatingActionButton({
  size,
  color,
  disabled,
  children,
  className,
  href,
  variant
}: FloatingActionButtonProps) {
  return (
    <Fab
      variant={variant}
      href={href}
      color={color}
      size={size}
      disabled={disabled}
      className={cx(className, styles.root, styles[`_color_${color}`])}
    >
      {children}
    </Fab>
  );
}

import React, { ReactNode, useCallback } from "react";

import Checkbox from "../checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";

type CheckboxGroupProps<valT> = {
  className?: string;
  options: {
    value: valT;
    label: string | ReactNode;
  }[];
  onChange: (nextValue: valT[]) => void;
  value: valT[];
};
export const CheckboxGroup = <valT extends string | number = string>({
  className,
  options,
  onChange,
  value
}: CheckboxGroupProps<valT>) => {
  return (
    <div className={className}>
      {options.map(option => (
        <FormControlLabel
          control={
            <Checkbox
              onChange={checked =>
                onChange(
                  checked && !value.includes(option.value)
                    ? [...value, option.value]
                    : value.filter(val => val !== option.value)
                )
              }
              checked={value.includes(option.value)}
            />
          }
          label={option.label}
          key={option.value}
        />
      ))}
    </div>
  );
};
export default CheckboxGroup;

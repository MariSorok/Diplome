import React, { ReactNode } from "react";
import TextField from "@material-ui/core/TextField";
import { withStyles } from "@material-ui/core/styles";
import MenuItem from "@material-ui/core/MenuItem";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";

const CssTextField = withStyles({
  root: {
    minWidth: "100px",
    borderRadius: "6px",
    // "& .MuiFormHelperText-root": {
    //   color: "#BEC0C2"
    // },
    "& label": {
      color: "#BEC0C2",
      "&.Mui-focused": {
        color: "#CDD0D3"
      },
      // "&.MuiFormLabel-filled + .MuiOutlinedInput-root .MuiOutlinedInput-inputMarginDense": {
      //   background: "#FFFFFF"
      // },

      "&.MuiFormLabel-root.Mui-disabled": {
        color: "#BEC0C2",
        opacity: "1"
      }
    },
    "& .MuiOutlinedInput-root": {
      color: "#273142",
      background: "#F9F9F9",
      "& input::placeholder": { color: "#BEC0C2", opacity: "1" },

      "& .MuiSelect-icon": {
        color: "#BEC0C2",
        background: "#F9F9F9",
        borderRadius: "6px",
        verticalAlign: "middle"
      },
      "& .MuiSelect-root": {
        color: "#273142"
      },
      "& .MuiOutlinedInput-inputMarginDense": {
        borderRadius: "6px",
        border: "none"
      },
      "& fieldset": {
        transition: "0.3s ease",
        border: "1px solid #F9F9F9"
      },
      "&:hover fieldset": {
        border: "1px solid #EEF0F1"
      },
      "&.Mui-focused": {
        background: "#FFFFFF",
        "&.MuiOutlinedInput-root .MuiOutlinedInput-inputMarginDense": {
          background: "#FFFFFF"
        }
      },
      "&.Mui-focused fieldset": {
        border: "1px solid #EEF0F1"
      },
      "&.Mui-disabled fieldset": { border: "none" }
    }
  }
})(TextField);
type InputProps = {
  rowsMax?: number | string;
  rows?: number | string;
  fullWidth?: boolean;
  options?: { label: string; value: string }[];
  select?: boolean;
  value?: ReactNode;
  autoComplete?: string;
  autoFocus?: boolean;
  disabled?: boolean;
  className?: string;
  defaultValue?: ReactNode;
  error?: boolean;
  required?: boolean;
  multiline?: boolean;
  name?: string;
  onChange?: (event: object) => void;
  placeholder?: string;
  type?: string;
  label?: string;
  id?: string;
  variant?: "outlined";
  size?: "small" | "medium";
  helperText?: string;
};
export default function Input({
  rowsMax,
  rows,
  fullWidth = false,
  options,
  select,
  value,
  multiline = false,
  autoComplete,
  className,
  defaultValue,
  disabled = false,
  error = false,
  autoFocus = false,
  required = false,
  name,
  onChange,
  placeholder,
  type,
  label,
  id,
  variant = "outlined",
  size = "small",
  helperText
}: InputProps) {
  return (
    <div className={className}>
      <CssTextField
        SelectProps={{
          IconComponent: ExpandMoreIcon
        }}
        rowsMax={rowsMax}
        fullWidth={fullWidth}
        select={select}
        value={value}
        size={size}
        label={label}
        type={type}
        placeholder={placeholder}
        onChange={onChange}
        name={name}
        multiline={multiline}
        defaultValue={defaultValue}
        autoComplete={autoComplete}
        disabled={disabled}
        error={error}
        autoFocus={autoFocus}
        required={required}
        id={id}
        variant={variant}
        rows={rows}
        helperText={helperText}
      >
        {select &&
          options &&
          options.map(option => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
      </CssTextField>
    </div>
  );
}

import React, { ReactNode, useCallback } from "react";
import { RadioGroup as MUIRadioGroup } from "@material-ui/core";

import Radio from "../radio/index";
import FormControlLabel from "@material-ui/core/FormControlLabel";

type Options = {
  value: string;
  label: string | ReactNode;
};

type RadioGroupProps = {
  value: string;
  className?: string;
  options: Options[];
  onChange?: (value: string) => void;
  disabled?: boolean;
};
export default function RadioGroup({
  className,
  options,
  onChange,
  disabled,
  value,
}: RadioGroupProps) {
  const handleChange = useCallback((val) => {
    onChange && onChange(val);
  }, []);

  return (
    <MUIRadioGroup onChange={handleChange} className={className}>
      {options.map((option) => (
        <FormControlLabel
          value={option.value}
          control={<Radio />}
          label={option.label}
          disabled={disabled}
          checked={option.value === value}
          key={option.value}
        />
      ))}
    </MUIRadioGroup>
  );
}

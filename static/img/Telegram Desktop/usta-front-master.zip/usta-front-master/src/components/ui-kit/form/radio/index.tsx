import React, { ReactNode } from "react";
import { Radio as MUIRadio } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import cx from "clsx";

const useStyles = makeStyles({
  root: {
    "&:hover": {
      backgroundColor: "transparent"
    }
  },
  icon: {
    borderRadius: "50%",
    width: 20,
    height: 20,
    background: "#F9F9F9",
    border: "1px solid #EEF0F1",
    "input:disabled ~ &": {
      boxShadow: "none",
      background: "#EEF0F1"
    }
  },
  checkedIcon: {
    width: 20,
    height: 20,
    border: "2px solid #FFFFFF",
    boxShadow: "0px 1px 9px rgba(0, 0, 0, 0.08)",
    backgroundImage: "linear-gradient(45deg, #61ADE5 0%, #8FC9F3 100%)"
  }
});
type RadioProps = {
  name?: string;
  checked?: boolean;
  className?: string;
  disabled?: boolean;
  onChange?: (event: object) => void;
  value?: string;
  disableRipple?: boolean;
  checkedIcon?: ReactNode;
  icon?: ReactNode;
};
export default function Radio({
  name,
  value,
  checked = false,
  className,
  disabled,
  onChange
}: RadioProps) {
  const classes = useStyles();
  return (
    <MUIRadio
      name={name}
      value={value}
      checked={checked}
      className={cx(classes.root, className)}
      disabled={disabled}
      onChange={onChange}
      disableRipple
      checkedIcon={<span className={cx(classes.icon, classes.checkedIcon)} />}
      icon={<span className={classes.icon} />}
    />
  );
}

import React, { ReactNode } from "react";
import cx from "clsx";
import styles from "./styles.module.scss";

type HeadingProps = {
  level?: "1" | "2" | "3" | "4" | "5";
  className?: string;
  children?: ReactNode;
};
export default function Heading({
  level = "1",
  className,
  children
}: HeadingProps) {
  return (
    <div className={cx(styles.root, className, styles[`_level_${level}`])}>
      {children}
    </div>
  );
}

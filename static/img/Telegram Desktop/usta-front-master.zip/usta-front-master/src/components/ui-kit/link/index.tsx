import { isExternalURL } from "../../../tools/url";
import cx from "clsx";
import { Link as ReactLink } from "react-router-dom";
import React from "react";

import styles from "./styles.module.scss";

export type LinkProps = {
  href: string;
  type?: "primary" | "secondary";
} & React.AnchorHTMLAttributes<HTMLAnchorElement>;

const otherProps = {
  __self: typeof globalThis,
};

const Link = ({ href, type = "primary", ...anchorProps }: LinkProps) => {
  return typeof href === "string" && isExternalURL(href) ? (
    <a
      href={href}
      {...anchorProps}
      className={cx(
        styles.root,
        anchorProps.className,
        styles[`_type_${type}`]
      )}
      referrerPolicy=''
    />
  ) : (
    <ReactLink
      {...otherProps}
      to={href}
      className={cx(
        styles.reactLinkRoot,
        anchorProps.className,
        styles[`_type_${type}`]
      )}
    >
      <a {...anchorProps} referrerPolicy='' />
    </ReactLink>
  );
};
export default Link;

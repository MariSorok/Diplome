import cx from "clsx";

import React from "react";

import { ReactComponent as LoaderIcon } from "./images/preloader.svg";
import styles from "./styles.module.scss";

type LoaderProps = {
  className?: string
}
const Loader = ({className}: LoaderProps) => {
  return (
    <div className={cx(className,styles.root)}>
      <LoaderIcon className={styles.loader} />
    </div>
  );
};

export default Loader;

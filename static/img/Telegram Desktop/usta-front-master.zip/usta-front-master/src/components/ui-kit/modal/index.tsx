import React, { ReactElement, useState } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import { Modal as ModalMUI } from "@material-ui/core";
import Backdrop from "@material-ui/core/Backdrop";
import Fade from "@material-ui/core/Fade";
import { ReactComponent as Close } from "./images/close.svg";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    modal: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      border: "none",
      background: "rgba(0, 0, 0, 0.75)"
    },
    paper: {
      minWidth: "200px",
      backgroundColor: "#ffffff",
      boxShadow: "0px 4px 25px rgba(0, 0, 0, 0.3)",
      borderRadius: "6px",
      padding: "15px",
      outline: "none",
      display: "flex",
      flexDirection: "column"
    },
    closeIcon: { alignSelf: "flex-end", cursor: "pointer" },
    content: {
      margin: "0 5px"
    }
  })
);

type ModalProps = {
  open: boolean;
  onClose: () => void;
  children: ReactElement;
};
const Modal = ({ open, onClose, children }: ModalProps) => {
  const classes = useStyles();
  return (
    <ModalMUI
      className={classes.modal}
      open={open}
      onClose={onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500
      }}
    >
      <Fade in={open}>
        <div className={classes.paper}>
          <Close className={classes.closeIcon} onClick={onClose} />
          <div className={classes.content}>{children}</div>
        </div>
      </Fade>
    </ModalMUI>
  );
};
export default Modal;

import React from "react";
import { Pagination as MUIPagination } from "@material-ui/lab";
import cx from "clsx";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles({
  root: {},
  pagination: {
    color: "#BEC0C2",
    "& .MuiPaginationItem-root": {
      color: "#BEC0C2",
      "&:hover": {
        background: "transparent",
        color: "#525A68"
      }
    },
    "& .MuiPaginationItem-page": {
      color: "#BEC0C2",
      "&.Mui-selected": {
        border: "1px solid #61ADE5",
        background: "#ffffff",
        color: "#61ADE5",
        "&:hover": {
          background: "transparent",
          color: "#61ADE5"
        }
      }
    }
  }
});

type PaginationProps = {
  boundaryCount?: number;
  count: number;
  defaultPage?: number;
  disabled?: boolean;
  hideNextButton?: boolean;
  hidePrevButton?: boolean;
  onChange?: (event: object, page: number) => void;
  className?: string;
  page?: number;
};
export default function Pagination({
  boundaryCount,
  count,
  defaultPage,
  disabled,
  hideNextButton,
  hidePrevButton,
  onChange,
  className,
  page
}: PaginationProps) {
  const classes = useStyles();

  return (
    <div className={cx(classes.root, className)}>
      <MUIPagination
        className={classes.pagination}
        count={count}
        boundaryCount={boundaryCount}
        defaultPage={defaultPage}
        disabled={disabled}
        hideNextButton={hideNextButton}
        hidePrevButton={hidePrevButton}
        onChange={onChange}
        page={page}
      />
    </div>
  );
}

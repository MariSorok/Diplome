import React, { ReactNode } from "react";

import styles from "./styles.module.scss";
import cx from "clsx";

type PassiveToggleButtonProps = {
  children?: ReactNode;
  value: string;
};

type PassiveToggleButtonsProps = {
  options: PassiveToggleButtonProps[];
  value?: string;
  className?: string;
};

export default function PassiveToggleButtons({
  options,
  value,
  className
}: PassiveToggleButtonsProps) {
  return (
    <div className={cx(className, styles.root)}>
      {options.map(option => {
        return (
          <div
            className={cx(styles.passiveToggleButton, {
              [styles["_active"]]: option.value === value
            })}
          >
            {option.children}
          </div>
        );
      })}
    </div>
  );
}

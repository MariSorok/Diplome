import React from "react";
import Star from "../star";
import styles from "./styles.module.scss";

type RatingProps = {
  className?: string;
  value: number;
};

export default function Rating({ className, value }: RatingProps) {
  return (
    <div className={className}>
      {Array(5)
        .fill(null)
        .map((_, index) => {
          const diff = value - index;
          return (
            <Star
              key={index}
              value={diff >= 1 ? 1 : diff > 0 ? diff : 0}
              className={styles.star}
            />
          );
        })}
    </div>
  );
}

import React from "react";
import cx from "clsx";
import Text from "../text";
import styles from "./styles.module.scss";
import { ReactComponent as Icon } from "./images/icon.svg";
import numeralizeRu from "../../../tools/numeralize-ru";

type ReviewProps = {
  className?: string;
  value: number;
};

export default function Review({ className, value }: ReviewProps) {
  return (
    <Text className={cx(styles.root, className)} level="4">
      <Icon />
      {numeralizeRu(value, ["отзыв", "отзыва", "отзывов"])}
    </Text>
  );
}

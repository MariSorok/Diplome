import React from "react";
import cx from "clsx";
import styles from "./styles.module.scss";
import star from "./images/star.svg";
import coloredStar from "./images/coloredStar.svg";

type StarProps = {
  className?: string;
  value: number;
};

export default function Star({ className, value }: StarProps) {
  return (
    <div className={cx(styles.root, className)}>
      <div className={styles.starUpper} style={{ width: `${value * 100}%` }}>
        <img src={coloredStar} />
      </div>
      <div className={styles.starLower}>
        <img src={star} />
      </div>
    </div>
  );
}

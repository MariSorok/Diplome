import React, { useState, ReactNode } from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { Stepper as MUIStepper } from "@material-ui/core";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import { ReactComponent as Tick } from "./images/tick.svg";
import StepConnector from "@material-ui/core/StepConnector";
import { StepIconProps } from "@material-ui/core/StepIcon";
import Text from "../text";
import Button from "../button";
import styles from "./styles.module.scss";
const StyledConnector = withStyles({
  alternativeLabel: {
    top: 10,
    left: "calc(-50% + 40px)",
    right: "calc(50% + 40px)"
  },
  active: {
    "& $line": {
      border: "1px dashed #61ADE5"
    }
  },
  completed: {
    "& $line": {
      border: "1px dashed #61ADE5"
    }
  },
  line: {
    border: "1px dashed #DFE1E3"
  }
})(StepConnector);

const useStepIconStyles = makeStyles({
  root: {
    color: "#DFE1E3",
    display: "flex",
    height: 22,
    alignItems: "center",
    fontWeght: 300,
    fontSize: "25px",
    lineHeight: "30px"
  },
  active: {
    color: "#61ADE5",
    "& $circle": { borderColor: "#61ADE5" }
  },
  circle: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 60,
    height: 60,
    borderRadius: "100%",
    backgroundColor: "#FFFFFF",
    border: "1px dashed #DFE1E3"
  },
  completed: {
    color: "#784af4",
    zIndex: 1,
    fontSize: 18,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "100%",
    backgroundColor: "#FFFFFF",
    width: 60,
    height: 60
  }
});

function stepIcon({ active, completed, icon }: StepIconProps) {
  const classes = useStepIconStyles();

  return (
    <div
      className={clsx(classes.root, {
        [classes.active]: active
      })}
    >
      {completed ? (
        <Tick className={classes.completed} />
      ) : (
        <div className={classes.circle}>{`0${icon}`}</div>
      )}
    </div>
  );
}

const StyledStepLabel = withStyles({
  root: {
    "& .MuiStepLabel-label.MuiStepLabel-alternativeLabel": {
      marginTop: "24px"
    }
  }
})(StepLabel);

type Steps = {
  title: string;
  description?: string;
  content?: ReactNode;
};
type StepperProps = {
  steps: Steps[];
};
export default function Stepper({ steps }: StepperProps) {
  const [activeStep, setActiveStep] = useState<number>(0);

  const handleNext = () => {
    setActiveStep(activeStep + 1);
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  return (
    <div>
      <MUIStepper
        alternativeLabel
        activeStep={activeStep}
        connector={<StyledConnector />}
      >
        {steps.map((step, index) => (
          <Step key={step.title}>
            <StyledStepLabel StepIconComponent={stepIcon}>
              <Text level="3">{step.title}</Text>
              <Text level="5">{step.description}</Text>
            </StyledStepLabel>
          </Step>
        ))}
      </MUIStepper>
      <div>
        {steps[activeStep].content}
        <div className={styles.buttons}>
          <Button disabled={activeStep === 0} onClick={handleBack} isRound>
            <Text level="3">Вернуться к предыдущему шагу</Text>
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            isRound
            className={styles.buttonNext}
          >
            <Text level="3">
              {activeStep === steps.length - 1
                ? "Добавить заявку в каталог"
                : "Перейти к следующему шагу"}
            </Text>
          </Button>
        </div>
      </div>
    </div>
  );
}

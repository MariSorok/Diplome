import React from "react";
import { withStyles, Theme, createStyles } from "@material-ui/core/styles";
import { Tabs as MUITabs } from "@material-ui/core";
import { Tab } from "@material-ui/core";

interface TabPanelProps {
  children?: React.ReactNode;
  index: string;
  value: string;
}

function TabPanel({ children, value, index, ...other }: TabPanelProps) {
  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`scrollable-prevent-tabpanel-${index}`}
      aria-labelledby={`scrollable-prevent-tab-${index}`}
      {...other}
    >
      {value === index && <>{children}</>}
    </div>
  );
}

function a11yProps(index: string) {
  return {
    id: `scrollable-prevent-tab-${index}`,
    "aria-controls": `scrollable-prevent-tabpanel-${index}`,
  };
}

const StyledTabs = withStyles({
  indicator: {
    backgroundColor: "transparent",
  },
})(MUITabs);

const StyledTab = withStyles((theme: Theme) =>
  createStyles({
    root: {
      color: "#BEC0C2",
      background: "#FAFAFA",
      border: "1px solid #F6F6F6",
      borderRadius: "6px",
      textTransform: "none",
      transition: "transform 0.3s ease",
      marginRight: "8px",

      "&:hover": {
        background: "#FFFFFF",
        border: "none",
        boxShadow: "0px 3px 15px rgba(0, 0, 0, 0.02)",
        transform: "translateY(-5px)",
      },

      "&$selected": {
        background: "#FFFFFF",
        boxShadow: "0px 3px 15px rgba(0, 0, 0, 0.02)",
        color: "#273142",

        "&:hover": {
          boxShadow: "none",
          transform: "none",
        },
      },
    },
    selected: {},
  })
)((props: Option) => <Tab disableRipple {...props} />);

type Option = {
  label: React.ReactNode;
  value: string;
  children?: React.ReactNode;
};

type TabsProps = {
  options: Option[];
  value: string;
  onChange: (event: React.ChangeEvent<{}>, newValue: string) => void;
};

export default function Tabs({ options, value, onChange }: TabsProps) {
  return (
    <>
      <StyledTabs value={value} onChange={onChange} scrollButtons='on'>
        {options.map((option) => (
          <StyledTab
            label={option.label}
            key={option.value}
            value={option.value}
            {...a11yProps(option.value)}
          />
        ))}
      </StyledTabs>
      {options.map((option) => (
        <TabPanel value={value} index={option.value}>
          {option.children}
        </TabPanel>
      ))}
    </>
  );
}

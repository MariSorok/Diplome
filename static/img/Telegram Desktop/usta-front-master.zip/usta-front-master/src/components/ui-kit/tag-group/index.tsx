import React, { ReactNode, useCallback } from "react";

import Tag from "../tag";

type Tags = {
  value: string;
  label: string | ReactNode;
};

type RadioGroupProps = {
  className?: string;
  tags: Tags[];
  disabled?: boolean;
  onDelete?: (value: string) => void;
};
export default function RadioGroup({
  className,
  tags,
  onDelete
}: RadioGroupProps) {
  const handleDelete = useCallback(value => {
    onDelete && onDelete(value);
  }, []);

  return (
    <div className={className}>
      {tags.map(option => (
        <Tag label={option.label} onDelete={() => handleDelete(option.value)} />
      ))}
    </div>
  );
}

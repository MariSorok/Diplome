import cx from "clsx";
import React from "react";
import Chip from "@material-ui/core/Chip";
import styles from "./styles.module.scss";
import { ReactComponent as DeleteIcon } from "./images/delete.svg";

type TagProps = {
  className?: string;
  label?: React.ReactNode;
  onDelete: (value: string) => void;
  size?: "medium" | "small";
  clickable?: boolean;
};

export default function Tag({
  className,
  label,
  onDelete,
  size = "medium",
  clickable,
}: TagProps) {
  return (
    <div className={cx(className, styles.root)}>
      <Chip
        className={styles.tag}
        label={label}
        onDelete={onDelete}
        deleteIcon={<DeleteIcon />}
        size={size}
        clickable={clickable}
      />
    </div>
  );
}

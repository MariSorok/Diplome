import React, { ReactNode } from "react";
import cx from "clsx";
import styles from "./styles.module.scss";

type TextProps = {
  level?: "1" | "2" | "3" | "4" | "5" | "6";
  className?: string;
  children?: ReactNode;
};
export default function Text({ level = "1", className, children }: TextProps) {
  return (
    <div className={cx(styles.root, className, styles[`_level_${level}`])}>
      {children}
    </div>
  );
}

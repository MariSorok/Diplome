import React, { ReactNode } from "react";

import { ToggleButton } from "@material-ui/lab";
import ToggleButtonGroup from "@material-ui/lab/ToggleButtonGroup";
import styles from "./styles.module.scss";
import cx from "clsx";

type ToggleButtonProps = {
  children?: ReactNode;
  value: string;
};

type ToggleButtonsProps = {
  options: ToggleButtonProps[];
  value?: string;
  exclusive?: boolean;
  onChange: (event: object, value: any) => void;
  size?: "large" | "medium" | "small";
  className?: string;
};

export default function ToggleButtons({
  options,
  value,
  exclusive,
  onChange,
  size,
  className
}: ToggleButtonsProps) {
  return (
    <ToggleButtonGroup
      value={value}
      exclusive={exclusive}
      onChange={onChange}
      size={size}
      className={cx(className, styles.root)}
    >
      {options.map(option => {
        return (
          <ToggleButton
            value={option.value}
            className={cx(styles.toggleButton, {
              [styles["_active"]]: option.value === value
            })}
          >
            {option.children}
          </ToggleButton>
        );
      })}
    </ToggleButtonGroup>
  );
}

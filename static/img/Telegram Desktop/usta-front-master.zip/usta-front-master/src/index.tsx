import * as React from "react";
import { render } from "react-dom";
import App from "./app";
import { BrowserRouter } from "react-router-dom";

const rootEl = document.getElementById("root");

const otherProps = {
  __self: typeof globalThis,
};

render(
  <BrowserRouter {...otherProps}>
    <App />
  </BrowserRouter>,
  rootEl
);

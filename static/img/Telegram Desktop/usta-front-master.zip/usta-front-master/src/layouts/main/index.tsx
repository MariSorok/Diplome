import cx from "clsx";
import React, { ReactNode } from "react";
import styles from "./styles.module.scss";
import { Container } from "../../components/ui-kit/gtid";

type BaseLayoutProps = {
  children: ReactNode;
  hasContainer?: boolean;
};

const otherProps = {
  __self: typeof globalThis,
};

const BaseLayout = ({ children, hasContainer = true }: BaseLayoutProps) => {
  return (
    <div className={cx(styles.main, { [styles._hasContainer]: hasContainer })}>
      {hasContainer ? (
        <Container className={styles.content} {...otherProps}>
          {children}
        </Container>
      ) : (
        children
      )}
    </div>
  );
};

export default BaseLayout;

// import { Trans } from ‘@lingui/macro’;
// import React, { useCallback, useMemo, useState } from ‘react’;

// import styles from ‘./styles.module.scss’;

// import LanguageSwitcher from ‘@aer/seller-center/app/desktop/components/language-switcher’;
// import Navigation from ‘@aer/seller-center/app/desktop/components/navigation’;
// import NavigationItem from ‘@aer/seller-center/app/desktop/components/navigation/components/navigation-item’;
// import NavigationMobile from ‘@aer/seller-center/app/desktop/containers/navigation-mobile’;
// import { RouteNames, Routes } from ‘@aer/seller-center/app/desktop/routes’;
// import { useLogoutUrl } from ‘@aer/seller-center/app/tools/passport’;
// import { useCurrentUser } from ‘@aer/seller-center/app/use-cases/current-user’;
// import { useNavigation } from ‘@aer/seller-center/app/use-cases/use-navigation’;
// import ContextHelp from ‘@aer/seller-center/seller/containers/desktop/context-help-widget’;
// import { RegistrationStepDTO } from ‘@aer/seller-center/seller/entities/store’;
// import { logout } from ‘@aer/shared/tools/auth’;
// import useDevice, { Device } from ‘@aer/shared/tools/media’;
// import { Col, Row } from ‘@aer/shared/ui-kit/components/grid’;
// import Header from ‘@aer/shared/ui-kit/components/header’;
// import Heading from ‘@aer/shared/ui-kit/components/heading’;
// import Icon from ‘@aer/shared/ui-kit/components/icon’;
// import Loader from ‘@aer/shared/ui-kit/components/loader’;
// import MenuItem from ‘@aer/shared/ui-kit/components/menu-item’;
// import Modal from ‘@aer/shared/ui-kit/components/modal’;
// import BaseLayout from ‘@aer/shared/ui-kit/layouts/base’;

// type MainLayoutProps = Omit<React.ComponentProps<typeof BaseLayout>, ‘header’>;

// const AuthorizedMobileHeaderContent = () => {
//   const navigation = useNavigation();

//   return (
//     <>
//       {navigation?.mobile.map(item => (
//         <Col key={item.link} width=“xs”>
//           <NavigationItem item={item} />
//         </Col>
//       ))}
//     </>
//   );
// };

// const MobileMenu = () => {
//   const { isAuthenticated, registrationStep } = useCurrentUser();
//   const [visible, setVisible] = useState<boolean>(false);

//   const isAuthorized = useMemo(
//     () =>
//       isAuthenticated &&
//       registrationStep?.step === RegistrationStepDTO.Finished,
//     [isAuthenticated, registrationStep?.step]
//   );

//   const handleOpen = useCallback(() => {
//     setVisible(true);
//   }, []);

//   const handleClose = useCallback(() => {
//     setVisible(false);
//   }, []);

//   const unauthorizedHeaderContent = useMemo(
//     () => (
//       <div className={styles.menuList}>
//         <div onClick={handleClose} className={styles.menuListItem}>
//           <MenuItem
//             to=“https://business.aliexpress.ru/faq”
//             target=“_blank”
//             rel=“noopener noreferrer”
//           >
//             <Trans id=“mainMenu.FAQ”>Вопросы и ответы</Trans>
//           </MenuItem>
//         </div>
//         <div onClick={handleClose} className={styles.menuListItem}>
//           <MenuItem
//             to=“https://service.aliexpress.com/page/home?spm=a2g0s.12525638.0.3.NktHbe&pageId=24&language=ru”
//             target=“_blank”
//             rel=“noopener noreferrer”
//           >
//             <Trans id=“mainMenu.chat”>Онлайн-чат</Trans>
//           </MenuItem>
//         </div>
//         <div onClick={handleClose} className={styles.menuListItem}>
//           <MenuItem to={Routes[RouteNames.LOGIN].create({})}>
//             <Trans id=“mainMenu.login”>Вход</Trans>
//           </MenuItem>
//         </div>
//         <div onClick={handleClose} className={styles.menuListItem}>
//           <MenuItem to={Routes[RouteNames.REGISTRATION].create({})}>
//             <Trans id=“mainMenu.registration”>Регистрация</Trans>
//           </MenuItem>
//         </div>
//         <div onClick={handleClose} className={styles.menuListItem}>
//           <LanguageSwitcher />
//         </div>
//       </div>
//     ),
//     [handleClose]
//   );

//   return (
//     <>
//       <Row align=“center” justify=“end”>
//         {isAuthorized && <AuthorizedMobileHeaderContent />}
//         <Icon
//           name=“MenuBurger”
//           size=“32”
//           onClick={handleOpen}
//           className={styles.icon}
//         />
//       </Row>
//       <Modal
//         visible={visible}
//         onClose={handleClose}
//         showCloseIcon
//         header={<Heading level=“6">Меню</Heading>}
//       >
//         {isAuthorized ? <NavigationMobile /> : unauthorizedHeaderContent}
//       </Modal>
//     </>
//   );
// };

// const AuthorizedDesktopHeaderContent = () => {
//   const navigation = useNavigation();

//   return <Navigation navigation={navigation} />;
// };

// const UnauthorizedDesktopHeaderContent = () => {
//   const { isAuthenticated } = useCurrentUser();
//   const logoutUrl = useLogoutUrl();

//   const handleLogoutClick = useCallback(
//     async (e: React.MouseEvent<HTMLElement>) => {
//       e.preventDefault();
//       await logout();
//       window.location.href = logoutUrl;
//     },
//     [logoutUrl]
//   );

//   return (
//     <Row align=“center” justify=“end” nowrap>
//       <Col width=“auto”>
//         <MenuItem
//           to=“https://business.aliexpress.ru/faq”
//           target=“_blank”
//           rel=“noopener noreferrer”
//         >
//           <Trans id=“mainMenu.FAQ”>Вопросы и ответы</Trans>
//         </MenuItem>
//       </Col>
//       <Col width=“auto”>
//         <MenuItem
//           to=“https://service.aliexpress.com/page/home?spm=a2g0s.12525638.0.3.NktHbe&pageId=24&language=ru”
//           target=“_blank”
//           rel=“noopener noreferrer”
//         >
//           <Trans id=“mainMenu.chat”>Онлайн-чат</Trans>
//         </MenuItem>
//       </Col>
//       {isAuthenticated && (
//         <Col width=“auto”>
//           <MenuItem to={logoutUrl} onClick={handleLogoutClick}>
//             <Trans id=“mainMenu.logout”>Выход</Trans>
//           </MenuItem>
//         </Col>
//       )}
//       {!isAuthenticated && (
//         <>
//           <Col width=“auto”>
//             <MenuItem to={Routes[RouteNames.LOGIN].create({})}>
//               <Trans id=“mainMenu.login”>Вход</Trans>
//             </MenuItem>
//           </Col>
//           <Col width=“auto”>
//             <MenuItem to={Routes[RouteNames.REGISTRATION].create({})}>
//               <Trans id=“mainMenu.registration”>Регистрация</Trans>
//             </MenuItem>
//           </Col>
//         </>
//       )}
//       <Col width=“auto”>
//         <LanguageSwitcher />
//       </Col>
//     </Row>
//   );
// };

// const DesktopMenu = () => {
//   const { isAuthenticated, registrationStep } = useCurrentUser();
//   const isAuthorized = useMemo(
//     () =>
//       isAuthenticated &&
//       registrationStep?.step === RegistrationStepDTO.Finished,
//     [isAuthenticated, registrationStep?.step]
//   );

//   return isAuthorized ? (
//     <AuthorizedDesktopHeaderContent />
//   ) : (
//     <UnauthorizedDesktopHeaderContent />
//   );
// };

// const HeaderContent = () => {
//   const device = useDevice();

//   return device === Device.Mobile ? <MobileMenu /> : <DesktopMenu />;
// };

// const MainLayout = ({ children, ...restProps }: MainLayoutProps) => {
//   const { isLoading } = useCurrentUser();

//   if (isLoading) {
//     return <Loader centered />;
//   }

//   return (
//     <BaseLayout
//       {...restProps}
//       header={
//         <Header
//           homepageLink={Routes[RouteNames.DASHBOARD].template()}
//           content={<HeaderContent />}
//         />
//       }
//     >
//       <ContextHelp>{children}</ContextHelp>
//     </BaseLayout>
//   );
// };

// export default MainLayout;

import { useState, useEffect } from "react";

const useMediaQuery = (mediaQuery: string) => {
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    const mediaQueryList = window.matchMedia(mediaQuery);
    const documentChangeHandler = () => setIsVerified(!!mediaQueryList.matches);

    mediaQueryList.addEventListener("change", documentChangeHandler);

    documentChangeHandler();
    return () => {
      mediaQueryList.removeEventListener("change", documentChangeHandler);
    };
  }, [mediaQuery]);

  return isVerified;
};
export enum Device {
  Mobile = "mobile",
  Tablet = "tablet",
  Desktop = "desktop",
}
const useDevice = () => {
  const isMobile = useMediaQuery("(max-width:767px)");
  const isDesktop = useMediaQuery("(min-width:1200px)");
  return isMobile ? Device.Mobile : isDesktop ? Device.Desktop : Device.Tablet;
};
export default useDevice;
